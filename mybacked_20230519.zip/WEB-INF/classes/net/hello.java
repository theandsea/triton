package net;

public class hello {
    /* 
    public static void main(String[] args) {
        // System.out.println("Hello, World!");
        System.out.println(xxx());
    }
*/
    public static String xxx(){
        return "Hello, World!";
    }
}
